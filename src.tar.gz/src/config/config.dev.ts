export const devConfig = {
  serverUrl: 'http://192.168.0.100:5173/',
  meidaPrefix: "/media/",
  imagePrefix: "/images/"
} 