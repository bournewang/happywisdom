export const prodConfig = {
  serverUrl: 'https://happywisdom.org',
  meidaPrefix: 'https://img.happywisdom.org/',
  imagePrefix: 'https://img.happywisdom.org/'
} 